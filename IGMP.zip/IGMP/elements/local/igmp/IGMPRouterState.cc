#include <click/config.h>
#include "IGMPRouterState.hh"
#include <click/timer.hh>

CLICK_DECLS

CLICK_ENDDECLS
EXPORT_ELEMENT(IGMPRouterState)
